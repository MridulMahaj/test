package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.*;

public class GoToLinkedPageTest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test(description = "Click link from homepage and verify linked page content")
    public void verifyLinkedPageNavigation() {
        // Step 1: Open homepage
        driver.get("file:///C:/Users/mridulmahajan/eclipse-workspace/testinglinks/src/test/resources/TestingLinksPortal/docs/index.html");

        // Step 2: Click the link to linkedpage.html
        WebElement link = driver.findElement(By.id("homepage"));
        link.click();

        // Step 3: Verify the linked page content
        WebElement linkedPageText = driver.findElement(By.id("linkedpage"));
        String actualText = linkedPageText.getText();
        Assert.assertEquals(actualText, "This is the linked page of the website", "Linked page text should match");

        Reporter.log("PASS : Successfully navigated to Linked Page and verified content", true);
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
