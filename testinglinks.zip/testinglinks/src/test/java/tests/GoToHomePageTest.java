package tests;	


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.*;

import pages.LinkedPage;


public class GoToHomePageTest{

    WebDriver driver;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }
    
    @Test(description = "Go to Homepage")
    public void gotohomepage() {
    	LinkedPage lp = new LinkedPage(driver);
    	lp.sendsucessmessage();
    	driver.get("file:///C:/Users/mridulmahajan/eclipse-workspace/testinglinks/src/test/resources/TestingLinksPortal/docs/index.html");
    	Reporter.log("PASS : Went to Homepage",true);
    }
}