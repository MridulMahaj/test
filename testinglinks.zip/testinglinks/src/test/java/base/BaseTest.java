package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.ITestResult;
import org.testng.annotations.*;

import utils.ScreenshotUtil;

import java.lang.reflect.Method;
import java.nio.file.Paths;
import java.time.Duration;

public class BaseTest {
    protected WebDriver webdriver;

    @Parameters({"browser"})
    @BeforeClass(alwaysRun = true)
    public void setUp(@Optional("chrome") String browser) {
        if (browser == null || browser.equals("${browser}")) {
            browser = System.getProperty("browser", "chrome");
        }
        switch (browser.toLowerCase()) {
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions fopts = new FirefoxOptions();
                webdriver = new FirefoxDriver(fopts);
                break;
            case "chrome":
            default:
                WebDriverManager.chromedriver().setup();
                ChromeOptions copts = new ChromeOptions();
                webdriver = new ChromeDriver(copts);
                break;
        }
        webdriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        webdriver.manage().window().maximize();
    }

    @AfterMethod(alwaysRun = true)
    public void afterEach(ITestResult result, Method method) {
        if (!result.isSuccess()) {
            ScreenshotUtil.takeScreenshot(webdriver, "FAILED_" + method.getName());
        }
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        if (webdriver != null) {
            webdriver.quit();
        }
    }

    protected String resourceUrl(String relativePath) {
        // Build file:// URL to local static HTML page
        String abs = Paths.get("src","test","resources","TestingLinksPortal","docs", relativePath).toAbsolutePath().toString();
        String prefix = System.getProperty("os.name").toLowerCase().contains("win") ? "file:///" : "file://";
        return prefix + abs.replace("\\\\", "/").replace("\\", "/");

    }
}
