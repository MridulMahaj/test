package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.BaseTest;


import java.util.List;
import java.util.regex.*;


import utils.ScreenshotUtil;

import java.nio.file.Paths;
import java.time.Duration;

public class LinkedPage extends BaseTest{
	private final WebDriver webdriver;
	private final By homepage = By.id("homepage");
	private final WebDriverWait wait;
	
	//Wait for 5 seconds here
	public LinkedPage(WebDriver webdriver) {
		this.webdriver = webdriver;
		this.wait = new WebDriverWait(webdriver,Duration.ofSeconds(5));
	}
	
	public void verifyLinkedPageText() {
        WebElement element = webdriver.findElement(By.id("linkedpage"));
        Assert.assertEquals(element.getText(), "This is the linked page of the website");
    }
	
	public String sendsuccessmessageforlinked() {
		return "Went to Linked Page successfully";
		
	}
	
	public String sendsucessmessage() {
		return "Went to Home Page successfully";
		
	}

}
