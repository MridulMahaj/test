package tests;
import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import java.util.regex.*;


import utils.ScreenshotUtil;

import java.nio.file.Paths;

public class CredentialsSubmitTest extends BaseTest {
	@BeforeMethod
	public void navigateToLoginPage() {
		String homeUrl = resourceUrl("index.html");
		webdriver.get(homeUrl);	
	}
	
	@Test(description = "Success !!!!")
	public void successfulsubscription() {
	    LoginPage lp = new LoginPage(webdriver);
	    lp.fillLoginForm("Mridul Mahajan", "12353212E3");
	    lp.submit();
	    String message = lp.sendsuccessmessage(); // Simulated success
	    Assert.assertEquals(message, "Aapka program chal raha hai");
	    Reporter.log("PASS: Successfull subscription",true);
	    
	}
	@Test(description = "Missing one field")
	public void missingfields() {
	    LoginPage lp = new LoginPage(webdriver);
	    lp.fillLoginForm(null, null); // Missing password
	    lp.submit();

	    ScreenshotUtil.takeScreenshot(webdriver, "Missed one or more than one field while filling the form !!!!");
	    Reporter.log(" PASS : Missed one or more than one fields while filling the form !!", true);
	}

	

}
