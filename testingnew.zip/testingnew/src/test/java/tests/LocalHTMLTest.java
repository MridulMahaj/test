package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocalHTMLTest {
    public static void main(String[] args) {
        // Set path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:/path/to/chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        // Load local HTML file
        driver.get("file:///C:/Users/verizon/eclipse-workspace/testingnew/src/test/resources/LoginAutomation/docs/index.html");

        // Example: Print page title
        System.out.println("Page Title: " + driver.getTitle());

        // Add your test logic here (e.g., find elements, click buttons, etc.)

        driver.quit();
    }
}
