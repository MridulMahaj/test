package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginPage {
	private final WebDriver webdriver;
	private final By username = By.id("Username");
	private final By password = By.id("Password");
	private final By loginbtn = By.id("login-btn");
	
	private final WebDriverWait wait;
	
	//Wait for 5 seconds here
	public LoginPage(WebDriver webdriver) {
		this.webdriver = webdriver;
		this.wait = new WebDriverWait(webdriver,Duration.ofSeconds(5));
	}
	
	//Fill the credentials
	public void fillLoginForm(String name, String passwd) {
	    WebElement usernameField = webdriver.findElement(username);
	    WebElement passwordField = webdriver.findElement(password);

	    usernameField.clear();
	    if (name != null) {
	        usernameField.sendKeys(name);
	    }

	    passwordField.clear();
	    if (passwd != null) {
	        passwordField.sendKeys(passwd);
	    }
	}

	
	
	public void submit() {
		webdriver.findElement(loginbtn).click();
	}
	
	public  String sendsuccessmessage() {
		return "Aapka program chal raha hai";
	}

}
