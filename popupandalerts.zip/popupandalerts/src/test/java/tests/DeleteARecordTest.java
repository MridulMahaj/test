package tests;
import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.DeleteARecord;

import java.util.List;
import java.util.regex.*;


import utils.ScreenshotUtil;

import java.nio.file.Paths;
import java.time.Duration;
import org.testng.annotations.BeforeMethod;

public class DeleteARecordTest extends BaseTest{

	@BeforeMethod
	public void navigatetorecordspage() {
		String homeUrl = resourceUrl("index.html");
		webdriver.get(homeUrl);	
	}
	
	@Test(description = "Deleting a record from the table")
	public void deleterecords() {
	    webdriver.get("file:///C:/Users/verizon/eclipse-workspace/popupandalerts/src/test/resources/PopUpAndAlertsAutomation/docs/index.html");

	    // Add a record
	    webdriver.findElement(By.id("username")).sendKeys("testuser");
	    webdriver.findElement(By.id("password")).sendKeys("testpass");
	    webdriver.findElement(By.id("add_a_record")).click();

	    // Verify record was added
	    List<WebElement> rowsBefore = webdriver.findElements(By.cssSelector("#recordTable tbody tr"));
	    Assert.assertEquals(rowsBefore.size(), 1, "Record should be added");

	    // Delete the record
	    webdriver.findElement(By.id("delete_a_record")).click();

	    // Verify record was deleted
	    List<WebElement> rowsAfter = webdriver.findElements(By.cssSelector("#recordTable tbody tr"));
	    Assert.assertEquals(rowsAfter.size(), 0, "Record should be deleted");
	    Reporter.log("PASS : Deleted Records Successfully !!!",true);
	}


}
