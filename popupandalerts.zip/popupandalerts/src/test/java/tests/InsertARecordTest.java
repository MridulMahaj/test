package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.*;

import java.util.List;

public class InsertARecordTest {

    WebDriver driver;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test(description = "Insert a record and verify it's added to the table")
    public void insertRecord() {
        driver.get("file:///C:/Users/verizon/eclipse-workspace/popupandalerts/src/test/resources/PopUpAndAlertsAutomation/docs/index.html");

        // Fill in the form
        driver.findElement(By.id("username")).sendKeys("newuser");
        driver.findElement(By.id("password")).sendKeys("newpass");

        // Click 'Add a record'
        driver.findElement(By.id("add_a_record")).click();

        // Verify the record is added
        List<WebElement> rows = driver.findElements(By.cssSelector("#recordTable tbody tr"));
        Assert.assertTrue(rows.size() > 0, "Record should be added");

        WebElement firstRow = rows.get(0);
        String username = firstRow.findElements(By.tagName("td")).get(0).getText();
        String password = firstRow.findElements(By.tagName("td")).get(1).getText();

        Assert.assertEquals(username, "newuser", "Username should match");
        Assert.assertEquals(password, "newpass", "Password should match");
        Reporter.log("PASS : Record Inserted Successfully !!",true);
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
