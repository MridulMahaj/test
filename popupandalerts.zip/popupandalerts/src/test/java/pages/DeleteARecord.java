package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.DeleteARecord;

import java.util.List;
import java.util.regex.*;


import utils.ScreenshotUtil;

import java.nio.file.Paths;
import java.time.Duration;

public class DeleteARecord {

	private final WebDriver webdriver;
	private final By username = By.id("username");
	private final By password = By.id("password");
	private final By add_a_record = By.id("add_a_record");
	private final By delete_a_record = By.id("delete_a_record");
	private final WebDriverWait wait;
	
	//Wait for 5 seconds here
	public DeleteARecord(WebDriver webdriver) {
		this.webdriver = webdriver;
		this.wait = new WebDriverWait(webdriver,Duration.ofSeconds(5));
	}
	
	public String sendsuccessmessage() {
		return "Deleted the records successfully !!!";
		
	}
}
