package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShoppingCart {

	private final WebDriver webdriver;
	private final By appleCheckBox = By.id("apple");
	private final By bananaCheckBox = By.id("banana");
	private final By orangeCheckBox = By.id("orange");
	private final By breadCheckBox = By.id("bread");
	private final By eggsCheckBox = By.id("eggs");
	private final WebDriverWait wait;
	
	//Wait for 5 seconds here
	public ShoppingCart(WebDriver webdriver) {
		this.webdriver = webdriver;
		this.wait = new WebDriverWait(webdriver,Duration.ofSeconds(5));
	}
	
	public String sendsuccessmessage() {
		return "Added to Cart Page !!!";
		
	}
}
