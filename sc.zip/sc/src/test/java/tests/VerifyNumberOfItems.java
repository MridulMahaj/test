package tests;

import org.testng.annotations.BeforeMethod;
import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.ShoppingCart;

import java.util.List;



import utils.ScreenshotUtil;

import java.nio.file.Paths;
import java.time.Duration;

public class VerifyNumberOfItems extends BaseTest{
	
	//Navigate to Shopping Cart to locate index.html local file in project
		@BeforeMethod
		public void navigateToShoppingCartPage() {
			String homeUrl = resourceUrl("index.html");
			webdriver.get(homeUrl);	
		}
		
		
		@Test(description = "Verify Number of items in cart")
		public void verifynumberofitemsincart() {
			ShoppingCart sc = new ShoppingCart(webdriver);
			List<WebElement> items = webdriver.findElements(By.name("item"));

	        // Log the number of items found
	        Reporter.log("Total items found in cart: " + items.size(), true);

	        // Assert the expected number of items (should be 5: Apple, Banana, Orange, Bread, Eggs)
	        Assert.assertEquals(items.size(), 5, "Expected 5 items in the cart");

	        // Optionally print item labels
	        for (WebElement item : items) {
	            String label = webdriver.findElement(By.cssSelector("label[for='" + item.getAttribute("id") + "']")).getText();
	            Reporter.log("Item: " + label, true);
			
		}
	        Reporter.log("PASS : Verified Number of Items in the cart",true);
		}
	}
