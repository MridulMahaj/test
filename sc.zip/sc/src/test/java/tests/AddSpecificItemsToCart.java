package tests;
import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.ShoppingCart;
import java.util.regex.*;


import utils.ScreenshotUtil;

import java.nio.file.Paths;
import java.time.Duration;

public class AddSpecificItemsToCart extends BaseTest {
	//Navigate to Shopping Cart to locate index.html local file in project
	@BeforeMethod
	public void navigateToShoppingCartPage() {
		String homeUrl = resourceUrl("index.html");
		webdriver.get(homeUrl);	
	}
	
	
	@Test(description = "Adding Specific Items to Cart")
	public void addingspecificitemstocart() {
		ShoppingCart sc = new ShoppingCart(webdriver);
		WebElement appleCheckBox = webdriver.findElement(By.id("apple"));
		WebElement breadCheckBox = webdriver.findElement(By.id("bread"));
		appleCheckBox.click();
		breadCheckBox.click();
		Assert.assertTrue(appleCheckBox.isSelected(), "Apple is selected !!!");
		Assert.assertTrue(breadCheckBox.isSelected(), "Bread is selected !!!!");
		ScreenshotUtil.takeScreenshot(webdriver, "selected_items.png");
		Reporter.log("PASS : Selected Items have been added to cart",true);
		
	}
	
		
}
