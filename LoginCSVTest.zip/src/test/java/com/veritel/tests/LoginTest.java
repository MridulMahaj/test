package com.veritel.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.*;
import java.util.*;

public class LoginTest {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @DataProvider(name = "loginData")
    public Iterator<Object[]> getLoginData() throws IOException {
        List<Object[]> testData = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader("data.csv"));
        String line;
        reader.readLine(); // skip header
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            testData.add(new Object[]{parts[0], parts[1], parts[2]});
        }
        reader.close();
        return testData.iterator();
    }

    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password, String expectedResult) {
        driver.get("https://www.veritel.com/login");

        WebElement userField = driver.findElement(By.id("username"));
        WebElement passField = driver.findElement(By.id("password"));
        WebElement loginBtn = driver.findElement(By.id("loginBtn"));

        userField.clear();
        userField.sendKeys(username);

        passField.clear();
        passField.sendKeys(password);

        loginBtn.click();

        boolean loginSuccess = false;
        try {
            driver.findElement(By.id("logoutBtn"));
            loginSuccess = true;
        } catch (Exception e) {
            loginSuccess = false;
        }

        if (expectedResult.equals("success")) {
            Assert.assertTrue(loginSuccess, "Expected login to succeed but failed.");
        } else {
            Assert.assertFalse(loginSuccess, "Expected login to fail but succeeded.");
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
