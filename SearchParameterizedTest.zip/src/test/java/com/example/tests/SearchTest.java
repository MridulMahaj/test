package com.example.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchTest {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @DataProvider(name = "searchData")
    public Object[][] searchData() {
        return new Object[][] {
                {"Selenium WebDriver"},
                {"TestNG DataProvider"},
                {"Maven Selenium"},
                {"Parameterized Testing"}
        };
    }

    @Test(dataProvider = "searchData")
    public void testSearchFunctionality(String searchTerm) {
        driver.get("https://www.google.com");

        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys(searchTerm);
        searchBox.submit();

        String pageTitle = driver.getTitle();
        System.out.println("Page title for term [" + searchTerm + "]: " + pageTitle);

        Assert.assertTrue(pageTitle.contains(searchTerm) || pageTitle.contains("Google"),
                "Page title did not match for search term: " + searchTerm);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
